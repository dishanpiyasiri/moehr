<?php

/**
 * This is the model class for table "employeeofficialinfo".
 *
 * The followings are the available columns in table 'employeeofficialinfo':
 * @property string $nic
 * @property string $employement_id
 * @property integer $institute_id
 * @property integer $current_designation_id
 * @property integer $current_grade_id
 * @property integer $department_id
 * @property string $emp_official_mobile
 * @property string $emp_official_email
 * @property string $wop_no
 * @property string $insuarence_id
 * @property integer $appt_type_id
 * @property string $app_subject
 * @property string $app_letter_date
 * @property string $app_letter_code
 * @property string $app_date
 * @property string $sallary_no
 */
class Employeeofficialinfo extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'employeeofficialinfo';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('institute_id, current_designation_id, current_grade_id, department_id, appt_type_id', 'numerical', 'integerOnly'=>true),
			array('nic, emp_official_mobile', 'length', 'max'=>12),
			array('employement_id', 'length', 'max'=>15),
			array('emp_official_email, wop_no, insuarence_id, app_subject, app_letter_code, sallary_no', 'length', 'max'=>45),
			array('app_letter_date, app_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('nic, employement_id, institute_id, current_designation_id, current_grade_id, department_id, emp_official_mobile, emp_official_email, wop_no, insuarence_id, appt_type_id, app_subject, app_letter_date, app_letter_code, app_date, sallary_no', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'nic' => 'Nic',
			'employement_id' => 'Employement',
			'institute_id' => 'Institute',
			'current_designation_id' => 'Current Designation',
			'current_grade_id' => 'Current Grade',
			'department_id' => 'Department',
			'emp_official_mobile' => 'Emp Official Mobile',
			'emp_official_email' => 'Emp Official Email',
			'wop_no' => 'Wop No',
			'insuarence_id' => 'Insuarence',
			'appt_type_id' => 'Appt Type',
			'app_subject' => 'App Subject',
			'app_letter_date' => 'App Letter Date',
			'app_letter_code' => 'App Letter Code',
			'app_date' => 'App Date',
			'sallary_no' => 'Sallary No',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('nic',$this->nic,true);
		$criteria->compare('employement_id',$this->employement_id,true);
		$criteria->compare('institute_id',$this->institute_id);
		$criteria->compare('current_designation_id',$this->current_designation_id);
		$criteria->compare('current_grade_id',$this->current_grade_id);
		$criteria->compare('department_id',$this->department_id);
		$criteria->compare('emp_official_mobile',$this->emp_official_mobile,true);
		$criteria->compare('emp_official_email',$this->emp_official_email,true);
		$criteria->compare('wop_no',$this->wop_no,true);
		$criteria->compare('insuarence_id',$this->insuarence_id,true);
		$criteria->compare('appt_type_id',$this->appt_type_id);
		$criteria->compare('app_subject',$this->app_subject,true);
		$criteria->compare('app_letter_date',$this->app_letter_date,true);
		$criteria->compare('app_letter_code',$this->app_letter_code,true);
		$criteria->compare('app_date',$this->app_date,true);
		$criteria->compare('sallary_no',$this->sallary_no,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Employeeofficialinfo the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
