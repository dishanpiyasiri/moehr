<?php

/**
 * This is the model class for table "employeebasicinfo".
 *
 * The followings are the available columns in table 'employeebasicinfo':
 * @property string $nic
 * @property string $name_with_initials
 * @property string $full_name
 * @property integer $title_id
 * @property string $dob
 * @property string $current_address
 * @property string $permenent_address
 * @property string $gender
 * @property integer $marriage_sate_id
 * @property string $date_of_birth
 * @property string $mobile_no
 * @property string $land_no
 * @property string $email
 * @property integer $gs_devision_id
 * @property integer $nationality_id
 * @property integer $religion_id
 * @property integer $educationzone_id
 * @property string $image
 * @property string $file_path_of_photo
 */
class Employeebasicinfo extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'employeebasicinfo';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('nic', 'required'),
			array('title_id, marriage_sate_id, gs_devision_id, nationality_id, religion_id, educationzone_id', 'numerical', 'integerOnly'=>true),
			array('nic, land_no', 'length', 'max'=>12),
			array('name_with_initials', 'length', 'max'=>80),
			array('full_name', 'length', 'max'=>127),
			array('current_address, permenent_address', 'length', 'max'=>150),
			array('gender', 'length', 'max'=>6),
			array('mobile_no', 'length', 'max'=>15),
			array('email', 'length', 'max'=>45),
			array('file_path_of_photo', 'length', 'max'=>70),
			array('dob, date_of_birth, image', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('nic, name_with_initials, full_name, title_id, dob, current_address, permenent_address, gender, marriage_sate_id, date_of_birth, mobile_no, land_no, email, gs_devision_id, nationality_id, religion_id, educationzone_id, image, file_path_of_photo', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'nic' => 'Nic',
			'name_with_initials' => 'Name With Initials',
			'full_name' => 'Full Name',
			'title_id' => 'Title',
			'dob' => 'Dob',
			'current_address' => 'Current Address',
			'permenent_address' => 'Permenent Address',
			'gender' => 'Gender',
			'marriage_sate_id' => 'Marriage Sate',
			'date_of_birth' => 'Date Of Birth',
			'mobile_no' => 'Mobile No',
			'land_no' => 'Land No',
			'email' => 'Email',
			'gs_devision_id' => 'Gs Devision',
			'nationality_id' => 'Nationality',
			'religion_id' => 'Religion',
			'educationzone_id' => 'Educationzone',
			'image' => 'Image',
			'file_path_of_photo' => 'File Path Of Photo',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('nic',$this->nic,true);
		$criteria->compare('name_with_initials',$this->name_with_initials,true);
		$criteria->compare('full_name',$this->full_name,true);
		$criteria->compare('title_id',$this->title_id);
		$criteria->compare('dob',$this->dob,true);
		$criteria->compare('current_address',$this->current_address,true);
		$criteria->compare('permenent_address',$this->permenent_address,true);
		$criteria->compare('gender',$this->gender,true);
		$criteria->compare('marriage_sate_id',$this->marriage_sate_id);
		$criteria->compare('date_of_birth',$this->date_of_birth,true);
		$criteria->compare('mobile_no',$this->mobile_no,true);
		$criteria->compare('land_no',$this->land_no,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('gs_devision_id',$this->gs_devision_id);
		$criteria->compare('nationality_id',$this->nationality_id);
		$criteria->compare('religion_id',$this->religion_id);
		$criteria->compare('educationzone_id',$this->educationzone_id);
		$criteria->compare('image',$this->image,true);
		$criteria->compare('file_path_of_photo',$this->file_path_of_photo,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Employeebasicinfo the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
